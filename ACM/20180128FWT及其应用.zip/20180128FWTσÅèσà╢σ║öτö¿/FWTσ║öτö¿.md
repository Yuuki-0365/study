## CSU 1911 Card Game



引入辅助数组A[i] B[i] ：数字i分别在第一二组中的频数

$Ans=\sum_{i|j=k}{A[i]*B[j]}$

卷积？FFT？FWT



##  HDU5909 Tree Cutting



#### 问题描述

一棵N个节点的树，每个节点有一个权值vi，子树的权值定义为子树内所有节点权值的异或和。问各个权值的子树分别有多少种？

N≤1000，0≤v＜1024

#### 问题分析

先序遍历子树，递归处理

定义状态$s[u][i]$: 以u为树根的所有子树中权值为i的种类数

初始时$s[u][vu]=1$，其余为0

依次考虑u的各个儿子v，计算出$s[v][]$ 后，考虑新增它后对$s[u][]$的影响

$Inc[k]=\sum_{i \bigoplus j=k}{s[u][i]*s[v][j]}$

更新：$s[u][k]+=Inc[k]$





## HDU6057 Kanade’s convolution

位运算的集合含义

$C[k]=\sum_{i~and~j=k}A[i~xor~j]*B[i~or~j]$ 

换元

$C[k]=\sum_{p~xor~q=k}A[p]*B[q]$ 

等价吗？

$C[k]=\sum_{p~xor~q=k}A[p]*2^{bit(p)}*B[q]  , ~p~and~q=p$

$C[k]=\sum_{p~xor~q=k}~[bit(q)-bit(p)=bit(k)]*A[p]*2^{bit(p)}*B[q] $

直接套用FWT？改造FWT！

$C[k]=\sum_{p~xor~q=k}A[p]*2^{bit(p)}*B[q]​$$

$=\sum_{p~xor~q=k}(\sum_{i=1}^{m} A[p][i]*2^{bit(p)})*(\sum_{j=1}^{m} B[q][j])$$

$=\sum_{i=1}^{m}\sum_{j=1}^{m}\sum_{p~xor~q=k} A[p][i]*2^{bit(p)}*B[q][j]$

$=\sum_{i=1}^{m}\sum_{j=1}^{m}D[i][j][k]$

$C[k]=\sum_{i=1}^{m}\sum_{j=1}^{m}[j-i=bit(k)]D[i][j][k]$