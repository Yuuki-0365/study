#include<iostream>
#include<cstring>
#include<algorithm>
#include<vector>
#include<cstdio>
using namespace std;
const int maxn=1e5+5,sz=400;
int n,m,k;
struct node {
    int l,r,id;
}Q[maxn];
int pos[maxn];

inline bool cmp(const node& A,const node&B) {
    if(pos[A.l]==pos[B.l]) {
        return pos[A.l]&1?A.r<B.r:A.r>B.r;
    }
    return pos[A.l]<pos[B.l];
}

int kase;
int Ans[maxn],ans;
inline void Ins(char x) {}
inline void Del(char x) {}
int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        scanf("%d%d", &n, &m);
        for(int i=1;i<=m;++i) {
            scanf("%d%d",&Q[i].l,&Q[i].r);
            Q[i].id=i;
        }
        for(int i=1;i<=n;++i)pos[i]=i/sz;
        sort(Q+1,Q+1+m,cmp);
        int l=1,r=0;
        for(int i=1;i<=m;++i){
            while(l<Q[i].l)Del(s[l]),++l;
            while(l>Q[i].l)--l,Ins(s[l]);
            while(r<Q[i].r)++r,Ins(s[r]);
            while(r>Q[i].r)Del(s[r]),--r;
            
            Ans[Q[i].id]=ans;
        }
        printf("Case #%d:\n",++kase);
        for(int i=1;i<=m;++i)printf("%d\n",Ans[i]);
    }
    return 0;
}
//http://bestcoder.hdu.edu.cn/contests/contest_showproblem.php?cid=820&pid=1002
