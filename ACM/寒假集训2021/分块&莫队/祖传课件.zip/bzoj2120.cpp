#include<bits/stdc++.h>
using namespace std;
const int maxn=10000+5;
 
int n,m;
int block,pos[maxn],col[maxn],ans[maxn];
int query_num;
struct aa
{
	int l,r,time,id;
	bool operator <(const aa &b)const
	{
		if (pos[l]!=pos[b.l]) return pos[l]<pos[b.l];
		if (pos[r]!=pos[b.r]) return pos[r]<pos[b.r];
		return time<b.time;
	}
}a[maxn];
int tim;
struct bb
{
	int x,y,z;
}q[maxn];
 
int tt[maxn*100],tmp,l,r,now;
 
inline void insert(int pos)
{
	++tt[col[pos]];
	if (tt[col[pos]]==1) ++tmp;
}
inline void del(int pos)
{
	--tt[col[pos]];
	if (tt[col[pos]]==0) --tmp; 
}
 
inline void in_time(int i)
{
	int pos=q[i].x,to=q[i].y,&from=q[i].z;
	if (pos>=l&&pos<=r) del(pos);
	from=col[pos];
	col[pos]=to;
	if (pos>=l&&pos<=r) insert(pos);
}
inline void out_time(int i)
{
	int pos=q[i].x,to=q[i].y,from=q[i].z;
	if (pos>=l&&pos<=r) del(pos);
	col[pos]=from;
	if (pos>=l&&pos<=r) insert(pos);
}
 
inline void work()
{
	l=1,r=0,now=0;
	for (int i=1;i<=query_num;i++)
	{
		while(r<a[i].r)++r,insert(r);
		while(r>a[i].r)del(r),--r;
		
		while(l<a[i].l)del(l),++l;
		while(l>a[i].l)--l,insert(l);
		
		while(now<a[i].time)++now,in_time(now);
		while(now>a[i].time)out_time(now),--now;
		ans[a[i].id]=tmp;
	}
}
int main()
{
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++) scanf("%d",&col[i]);
	block=sqrt(n);
	for (int i=1;i<=n;i++) pos[i]=(i-1)/block+1;
	
	char ch[2];
	int x,y;
	for (int i=1;i<=m;i++)
	{
		scanf("%s",ch);
		scanf("%d%d",&x,&y);
		if (ch[0]=='Q') a[++query_num]=(aa){x,y,tim,i};
		else q[++tim]=(bb){x,y,0};
	}
	sort(a+1,a+query_num+1);
	work();
	for (int i=1;i<=m;i++) if(ans[i])printf("%d\n",ans[i]);
	return 0;
}